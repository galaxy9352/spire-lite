using NUnit.Framework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum TurnState
{
    PlayerTurnStart=0,
    OnPlayerTurn=1,
    PlayerTurnEnd=2,
    EnemyTurnStart=3,
    OnEnemyTurn=4,
    EnemyTurnEnd=5
}
public class TurnBaseSystem: MonoBehaviour
{
    public static TurnBaseSystem Instance;
    public int turnCount=0;
    public TurnState turnState = 0;
    public List<PlayerFighter> players = new List<PlayerFighter>();
    public List<MonsterFighter> enemies = new List<MonsterFighter>();
    public Button endTurnButton;

    public void StartTurnBattle()
    {
        turnCount = 1;
        turnState = TurnState.PlayerTurnStart;
        ActivateTurnState();
    }

    public void ShiftTurnState()
    {
        turnState++;
        if ((int)turnState > 5)
        {
            turnState = 0;
            turnCount++;
        }
        //StartCoroutine(DelayActivateTurnState());
        ActivateTurnState();
    }
    IEnumerator DelayActivateTurnState()
    {
        yield return new WaitForSeconds(3.0f);
        ActivateTurnState();
    }


    public void ActivateTurnState()
    {
        switch (turnState)
        {
            case TurnState.PlayerTurnStart:
                Debug.Log("Player Turn Start");
                foreach(var player in players)
                {
                    player.onMyTurnStart();
                }
                foreach(var enemy in enemies)
                {
                    enemy.onYourTurnStart();
                }
                break;
            case TurnState.OnPlayerTurn:
                Debug.Log("On Player Turn");
                foreach(var player in players)
                {
                    player.onMyTurn();
                }
                foreach(var enemy in enemies)
                {
                    enemy.onYourTurn();
                }
                break;
            case TurnState.PlayerTurnEnd:
                Debug.Log("Player Turn End");
                foreach (var player in players)
                {
                    player.onMyTurnEnd();
                }
                foreach (var enemy in enemies)
                {
                    enemy.onYourTurnEnd();
                }
                break;
            case TurnState.EnemyTurnStart:
                Debug.Log("Enemy Turn Start");
                foreach (var player in players)
                {
                    player.onYourTurnStart();
                }
                foreach (var enemy in enemies)
                {
                    enemy.onMyTurnStart();
                }
                break;
            case TurnState.OnEnemyTurn:
                Debug.Log("On Enemy Turn");
                foreach (var player in players)
                {
                    player.onYourTurn();
                }
                foreach (var enemy in enemies)
                {
                    enemy.onMyTurn();
                }
                break;
            case TurnState.EnemyTurnEnd:
                Debug.Log("Enemy Turn End");
                foreach (var player in players)
                {
                    player.onYourTurnEnd();
                }
                foreach (var enemy in enemies)
                {
                    enemy.onMyTurnEnd();
                }
                break;
        }
    }

    private void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
        
    }
    private void Start()
    {
        GameObject[] playerObjects = GameObject.FindGameObjectsWithTag("Player");
        GameObject[] enemyObjects = GameObject.FindGameObjectsWithTag("Enemy");
        endTurnButton=gameObject.GetComponent<Button>();
        foreach (var player in playerObjects)
        {
            players.Add(player.GetComponent<PlayerFighter>());
        }
        foreach (var enemy in enemyObjects)
        {
            enemies.Add(enemy.GetComponent<MonsterFighter>());
        }
        endTurnButton.onClick.AddListener(endPlayerTrun);
        StartTurnBattle();
    }

    public void endPlayerTrun()
    {
        if (turnState == TurnState.OnPlayerTurn)
        {
            ShiftTurnState();
        }
    }
}
