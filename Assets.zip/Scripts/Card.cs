﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;
using Unity.VisualScripting;

public enum CardType
{
    Attack,Skill,Effect
}
public enum EffectType
{
    Damage,Guard, AffectStatus
}

[CreateAssetMenu(fileName = "NewCard", menuName = "Cards/BasicCard")]
public class CardData : ScriptableObject
{
    public string cardName;
    public int cost;
    public Sprite cardArt;
    public List<CardEffect> cardEffects= new List<CardEffect>();
    public List<int> effectAmounts;
    public string description;
    public CardType cardType;
    public bool isTargetable;
    public void UseCard(PlayerFighter user, Fighter target)
    {
        if (user.curEnergy < cost)
        {
            Debug.Log("코스트 부족함");
            return;
        }
        for (int i = 0; i < cardEffects.Count; i++)
        {
            cardEffects[i].ApplyEffect(user, target, effectAmounts[i]);
        }
    }
}
[CreateAssetMenu(fileName = "NewCardEffect", menuName = "Cards/CardEffect")]
public class CardEffect: ScriptableObject
{
    public EffectType effectType;
    public int statusEffectIndex; // Only used if effectType is AffectStatus
    public void ApplyEffect(Fighter user, Fighter target, int amount)
    {
        if (effectType == EffectType.Damage)
        {
            user.Attack(target, amount);
        }
        else if (effectType == EffectType.Guard)
        {
            target.Guard(amount);
        }
        else if (effectType == EffectType.AffectStatus)
        {
            // Implement status effect logic here
            if (statusEffectIndex == 0)
            {
                target.gainPower(amount);
            }
            else if (statusEffectIndex == 1)
            {
                target.gainDex(amount);
            }
            else if (statusEffectIndex == 2)
            {
                target.gainDamaged(amount);
            }
            else if (statusEffectIndex == 3)
            {
                target.gainWeakness(amount);
            }
            else if (statusEffectIndex == 4)
            {
                target.gainFragile(amount);
            }
        }
    }
}

public class Card: MonoBehaviour, IPointerClickHandler
{
    public CardData cardData;

    public bool isSelected = false;

    public Image cardImage;
    public TextMeshProUGUI cardType;
    public TextMeshProUGUI cardName;
    public TextMeshProUGUI cardDesc;

    void Start()
    {
        cardImage = gameObject.transform.GetChild(0).GetComponent<Image>();
        cardType = gameObject.transform.GetChild(1).GetChild(0).GetComponent<TextMeshProUGUI>();
        cardName = gameObject.transform.GetChild(1).GetChild(1).GetComponent<TextMeshProUGUI>();
        cardDesc = gameObject.transform.GetChild(1).GetChild(2).GetComponent<TextMeshProUGUI>();
        ApplyCardData();
        
    }
    public void OnPointerClick(PointerEventData eventData)
    {
        // Implement card click behavior here
        Debug.Log("Card clicked: " + cardData.cardName);
        
        CardManager.Instance.OnCardSelected(cardData);
        //cardData.UseCard(GameObject.FindGameObjectWithTag("Player").GetComponent<Fighter>(), GameObject.FindGameObjectWithTag("Enemy").GetComponent<Fighter>());

    }
    void Update()
    {

    }
    public void ApplyCardData()
    { 
        cardImage.sprite=cardData.cardArt;
        cardName.text=cardData.cardName+ "(" + cardData.cost + ")";
        cardDesc.text=cardData.description;
        cardType.text=cardData.cardType.ToString();

    }


}