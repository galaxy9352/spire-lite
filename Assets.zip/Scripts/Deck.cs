﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Deck: MonoBehaviour 
{
    public List<Card> deck = new List<Card>();
    public List<Card> drawDeck= new List<Card>();
    public List<Card> discardDeck= new List<Card>();
    public List<Card> deletedCards= new List<Card>();
    public List<Card> hand= new List<Card>();
}