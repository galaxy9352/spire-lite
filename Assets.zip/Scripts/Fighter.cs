
using System;
using System.Collections.Generic;
using Unity.Mathematics;
using Unity.XR.OpenVR;
using UnityEngine;
using UnityEngine.EventSystems;

public class Fighter : MonoBehaviour, IPointerClickHandler
{
    public int maxHp = 0;
    public int curHp = 0;
    public int shield = 0;
    public EffectCollection effects;
    protected int power = 0;
    protected int dex = 0;
    protected List<StatusEffect> effectQue = new List<StatusEffect>();
    protected List<int> effectValue= new List<int>();

    //effeft status flags
    public bool isDamaged = false;
    public bool isWeakened = false;
    public bool isFragiled = false;



    protected Fighter()
    {

    }

    public virtual void onMyTurnStart()
    {
        for (int i = 0; i < effectValue.Count; i++)
        {
            if (effectQue[i].isPermanent == false)
            {
                effectValue[i]--;
            }
        }
        validateStatusQue();
    }
    public virtual void onMyTurn()
    {

    }

    public virtual void onMyTurnEnd()
    {

    }
    public virtual void onYourTurnStart()
    {

    }
    public virtual void onYourTurn()
    {

    }

    public virtual void onYourTurnEnd()
    {
        shield = 0;
    }


    public void OnPointerClick(PointerEventData eventData)
    {
        CardManager.Instance.OnTargetSelected(this);
    }



    public void Attack(Fighter target, int amount)
    {
        int damage = CalcDamage(amount);
        target.GetDamage(damage);
        Debug.Log(amount+", "+ target.curHp);
    }
    public void Guard(int amount)
    {
        int guardAmount = CalcGuard(amount);
        shield += amount;
    }
    protected int CalcDamage(int amount)
    {
        amount += power;
        if (isWeakened)
        {
            amount=amount*3/4;
        }
        return amount;
    }
    protected int CalcGuard(int amount)
    {
        amount += dex;
        return amount;
    }

    protected void GetDamage(int damage)// 피해를 입는 함수
    {
        if (isFragiled)
        { 
            damage=damage*3/2;
            Debug.Log(damage);
        }
        if (shield >= damage)
        {
            shield-=damage;
        }
        else
        {
            damage -= shield;
            shield = 0;
            curHp-=damage;
        }
    }


    public void gainPower(int amount)
    {
        power += amount;
        addStatusQue(effects.statusEffects[0], power);

    }
    public void gainDex(int amount)
    {
        dex += amount;
        if(dex > 0)
        addStatusQue(effects.statusEffects[1], dex);
    }
    public void gainDamaged(int amount)// 손상을 받는 함수
    {
        isDamaged = true;
        addStatusQue(effects.statusEffects[2], amount);
    }
    public void gainWeakness(int amount)// 약화를 받는 함수
    {
        isWeakened = true;
        addStatusQue(effects.statusEffects[3], amount);
    }
    public void gainFragile(int amount)// 취약을 받는 함수
    {
        isFragiled = true;
        addStatusQue(effects.statusEffects[4], amount);
    }


    protected void addStatusQue(StatusEffect effect, int amount)
    {
        bool isNew = true;
        foreach (StatusEffect e in effectQue)
        {
            if (e.effectName == effect.effectName)
            {
                isNew = false;
                effectValue[effectQue.IndexOf(e)]+= amount;
                break;
            }
        }
        if (isNew)
        {
            effectQue.Add(effect);
            effectValue.Add(amount);
        }
        validateStatusQue();
    }
    public void validateStatusQue()
    {
        bool[] hasStatuses = {false,false,false,false,false};

        for (int i = 0; i < effectQue.Count; i++)
        {
            if (effectValue[i] == 0)
            {
                effectQue.RemoveAt(i);
                effectValue.RemoveAt(i);
            }
        }
        for(int i = 0;i < effectQue.Count; i++)
        {
            if(effectQue[i].effectName == effects.statusEffects[0].effectName)
            {
                hasStatuses[0] = true;
            }
            else if (effectQue[i].effectName == effects.statusEffects[1].effectName)
            {
                hasStatuses[1] = true;
            }
            else if (effectQue[i].effectName == effects.statusEffects[2].effectName)
            {
                hasStatuses[2] = true;
            }
            else if (effectQue[i].effectName == effects.statusEffects[3].effectName)
            {
                hasStatuses[3] = true;
            }
            else if (effectQue[i].effectName == effects.statusEffects[4].effectName)
            {
                hasStatuses[4] = true;
            }
        }
        if(!hasStatuses[0])
        {
            power = 0;
        }
        if (!hasStatuses[1])
        {
            dex = 0;
        }
        isDamaged=hasStatuses[2];
        isWeakened=hasStatuses[3];
        isFragiled=hasStatuses[4];
    }


    public bool IsGuard()
    {
        if (shield <= 0)
        {
            return false;
        }
        else
        {
            return true;
        }
    }




    // Start is called once before the first execution of Update after the MonoBehaviour is created
    protected virtual void Start()
    {
        curHp = maxHp;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
