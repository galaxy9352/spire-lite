﻿using UnityEngine;
using System.Collections;
using UnityEditor.Build;

public class CardManager: MonoBehaviour
{
	public static CardManager Instance;

	public CardData selectedData;
	public Fighter target;
	public PlayerFighter user;
	bool isTargeting;

    // Use this for initialization
    void Awake()
	{
		if(Instance == null)
			Instance= this;
		else
		{
			Destroy(gameObject);
		}
	}
	public void OnCardSelected(CardData data)
	{
		selectedData = data;
		isTargeting = true;
    }
	public void OnTargetSelected(Fighter target)
	{
		if (!isTargeting || selectedData == null) return;
		this.target = target;
		user= getCardUser();

        selectedData.UseCard(user, target);
		isTargeting=false;
		selectedData = null;
    }
	PlayerFighter getCardUser()
	{
		return GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerFighter>();
    }

    // Update is called once per frame
    void Update()
	{

	}
}