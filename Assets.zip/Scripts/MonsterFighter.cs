
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;




public class MonsterFighter : Fighter
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public bool atkPattern=false;
    public bool grdPattern=false;
    public bool dbfPattern=false;

    public bool isMyTurnStart = false;
    public bool isMyTurn = false;
    public bool isMyTurnEnd = false;
    public int atkDamage=0;

    protected override void Start()
    {
        base.Start();
        GameObject[] playerObjects=GameObject.FindGameObjectsWithTag("Player");
        foreach (GameObject playerObject in playerObjects)
        {
            //enemies.Add(playerObject.GetComponent<Fighter>());
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public override void onMyTurnStart()
    {
        base.onMyTurnStart();
        isMyTurnStart=true;
    }
    public override void onMyTurn()
    {
        base.onMyTurn();
        ActivatePattern();
        isMyTurn=true;
    }
    public override void onMyTurnEnd()
    {
        base.onMyTurnEnd();
        TurnBaseSystem.Instance.ShiftTurnState();
        isMyTurnEnd=true;
    }
    public override void onYourTurnStart()
    {
        base.onYourTurnStart();
        MakeNextPattern();
    }
    public void ActivatePattern()
    {
        List<Fighter> player = new List<Fighter>();
        foreach (GameObject playerFighter in GameObject.FindGameObjectsWithTag("Player"))
        {
            player.Add(playerFighter.GetComponent<Fighter>());
        }
        //foreach (MonsterPattern pattern in patterns)
        //{
        //    if(pattern == MonsterPattern.Attack)
        //    {
        //        foreach (Fighter target in player)
        //        {
        //            Attack(target, Random.Range(7,12));
        //        }
        //    }
        //    else if (pattern == MonsterPattern.Guard)
        //    {
        //        Guard(Random.Range(5,10));
        //    }
        //    else if (pattern == MonsterPattern.StatusEffect)
        //    {
        //        int randomStatus = Random.Range(0, 3);
        //        switch (randomStatus)
        //        {
        //            case 0:
        //                foreach (Fighter target in player)
        //                {
        //                    target.gainDamaged(2);
        //                }
        //                break;
        //            case 1:
        //                foreach (Fighter target in player)
        //                {
        //                    target.gainWeakness(2);
        //                }
        //                break;
        //            case 2:
        //                foreach (Fighter target in player)
        //                {
        //                    target.gainFragile(2);
        //                }
        //                break;
        //        }

        //    }
        //}
        if (atkPattern)
        {
            
            foreach (Fighter target in player)
            {
                Attack(target, atkDamage);
            }
            atkPattern = false;
        }
        if(grdPattern)
        {
            Guard(Random.Range(5, 10));
            grdPattern = false;
        }
        if (dbfPattern)
        {
            int randomStatus = Random.Range(0, 3);
            switch (randomStatus)
            {
                case 0:
                    foreach (Fighter target in player)
                    {
                        target.gainDamaged(2);
                    }
                    break;
                case 1:
                    foreach (Fighter target in player)
                    {
                        target.gainWeakness(2);
                    }
                    break;
                case 2:
                    foreach (Fighter target in player)
                    {
                        target.gainFragile(2);
                    }
                    break;
            }
            dbfPattern = false;
        }
    }
    public void MakeNextPattern()
    {
        if (Random.Range(0, 2) == 0)
        {
            atkPattern = true;
            atkDamage = Random.Range(7, 12);
        }
        if (Random.Range(0, 2) == 0)
        {
            grdPattern = true;
        }
        if (Random.Range(0, 2) == 0)
        {
            dbfPattern = true;
        }
        if (!atkPattern&&!grdPattern&&!dbfPattern)
        {
            atkPattern = true;
        }
    }

}
