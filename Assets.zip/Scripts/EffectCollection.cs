﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


[CreateAssetMenu(fileName = "EffectCollection", menuName = "Collections/EffectCollection")]
public class EffectCollection : ScriptableObject
{
    public List<StatusEffect> statusEffects = new List<StatusEffect>();

}