﻿using UnityEngine;
using System.Collections;

[CreateAssetMenu(fileName = "NewEffect", menuName = "Effects/BasicEffect")]
public class StatusEffect : ScriptableObject
{
    public string effectName;
    public Sprite effectIcon;
    public string description;
    public bool isPermanent;
    public bool isPositive;


}