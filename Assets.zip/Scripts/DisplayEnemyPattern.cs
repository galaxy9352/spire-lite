using TMPro;
using UnityEngine;

public class DisplayEnemyPattern : MonoBehaviour
{
    GameObject atkImage;
    TextMeshProUGUI atkText;
    GameObject defImage;
    GameObject dbfImage;
    MonsterFighter monsterFighter;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        atkImage = transform.GetChild(0).gameObject;
        atkText = atkImage.transform.GetChild(0).GetComponent<TextMeshProUGUI>();
        defImage = transform.GetChild(1).gameObject;
        dbfImage = transform.GetChild(2).gameObject;
        monsterFighter = transform.parent.GetComponent<MonsterFighter>();
    }

    // Update is called once per frame
    void Update()
    {
        if (monsterFighter.atkPattern)
        {
            atkImage.SetActive(true);
            atkText.text=monsterFighter.atkDamage.ToString();
        }
        else
        {
            atkImage.SetActive(false);
        }
        if(monsterFighter.grdPattern)
        {
            defImage.SetActive(true);
        }
        else
        {
            defImage.SetActive(false);
        }
        if (monsterFighter.dbfPattern)
        {
            dbfImage.SetActive(true);
        }
        else 
        {
            defImage.SetActive(false);
        }
    }
}
