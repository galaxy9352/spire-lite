
using System;
using System.Collections.Generic;
using UnityEngine;

public class PlayerFighter : Fighter
{
    public int maxEnergy=3;
    public int curEnergy;
    public bool isCardPlayable = false;
    public List<MonsterFighter> enemise=new List<MonsterFighter>();





    protected override void Start()
    {
        base.Start();
        GameObject[] enemyObjects = GameObject.FindGameObjectsWithTag("Enemy");
        foreach (GameObject enemyObject in enemyObjects)
        {
            enemise.Add(enemyObject.GetComponent<MonsterFighter>());
        }
        curEnergy = maxEnergy;
        Debug.Log(enemyObjects.Length);
    }


    void Update()
    {
        if(TurnBaseSystem.Instance.turnState==TurnState.EnemyTurnStart)
        {
            bool isEnemyTurnStart = true;
            foreach (var enemy in enemise)
            {
                if (enemy.isMyTurnStart == false)
                {
                    isEnemyTurnStart = false;
                    break;
                }
            }
            if (isEnemyTurnStart == true)
            {
                TurnBaseSystem.Instance.ShiftTurnState();
                foreach (var enemy in enemise)
                {
                    enemy.isMyTurnStart = false;
                }
            }
        }
        if (TurnBaseSystem.Instance.turnState == TurnState.OnEnemyTurn)
        {
            bool isEnemyTurn = true;
            foreach (var enemy in enemise)
            {
                if (enemy.isMyTurn == false)
                {
                    isEnemyTurn = false;
                    break;
                }
            }
            if (isEnemyTurn == true)
            {
                TurnBaseSystem.Instance.ShiftTurnState();
                foreach (var enemy in enemise)
                {
                    enemy.isMyTurn = false;
                }
            }
        }
        if (TurnBaseSystem.Instance.turnState == TurnState.EnemyTurnEnd)
        {
            bool isEnemyTurnEnd = true;
            foreach (var enemy in enemise)
            {
                if (enemy.isMyTurnEnd == false)
                {
                    isEnemyTurnEnd = false;
                    break;
                }
            }
            if (isEnemyTurnEnd == true)
            {
                TurnBaseSystem.Instance.ShiftTurnState();
                foreach (var enemy in enemise)
                {
                    enemy.isMyTurnEnd = false;
                }
            }
        }
    }
    public override void onMyTurnStart()
    {
        base.onMyTurnStart();
        curEnergy = maxEnergy;
        isCardPlayable = true;
        TurnBaseSystem.Instance.ShiftTurnState();
    }

     public override void onMyTurnEnd()
    {
        base.onMyTurnEnd();
        isCardPlayable = false;
        TurnBaseSystem.Instance.ShiftTurnState();
    }

}
