﻿using UnityEngine;
using System.Collections;

public class BattleManager: MonoBehaviour
{
	public static BattleManager instance;

	public CardData selectedData;
	public Fighter target;
	public Fighter user;

    // Use this for initialization
    void Start()
	{

	}

	// Update is called once per frame
	void Update()
	{

	}
}